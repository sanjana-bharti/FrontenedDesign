import './App.css';
import {HomePage} from "./Components/Homepage";
import {Route,Routes, Switch,BrowserRouter as Router } from 'react-router-dom';
import {Cart} from "./Components/Cart";
import React from "react";
function App() {
  return (
      <Router>
          <div className="App">
              <Switch>
                  <Route exact path='/' component={HomePage}/>
                  <Route exact path='/cart' component={Cart}/>
              </Switch>
          </div>
      </Router>
  );
}

export default App;
