import React,{Component} from "react";
import {CartCard} from "./CartCard";
export class Cart extends Component {

    render() {
        let cartItems=this.props.cartItems;
        return (
            <div>
                    <h1 style={{color:"#C579D2"}}>
                        Cart
                    </h1>
                <div
                    style={{display: 'flex', flexDirection: 'row',background:"#F1C3CE"}}>
                    {
                       cartItems.length>0? cartItems.map((product) => {
                            return <CartCard product={product}/>
                       }):(<div style={{width: "100%",
                               height: "200px",
                               display: "flex",
                               justifyContent: "center",
                               alignItems: "center",
                               color:"#C579D2"
                       }}>
                               Cart is Empty , Add some Items !
                                   </div>
                       )
                    }
                </div>
                {this.props.cartItems.length>0 ?<div
                    onClick={()=>{
                        alert("Checking Out !");
                        console.log("Checking Out ");
                    }}
                    style={{
                        background:"red",
                        width:100,
                        margin: "10px",
                        padding: "10px"
                    }}>
                    CHECKOUT
                </div>:null}
            </div>
        );
    }
}