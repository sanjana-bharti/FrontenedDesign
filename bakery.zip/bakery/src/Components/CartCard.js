import React,{Component} from "react";
export class CartCard extends Component
{

    constructor(props) {
        super(props);
        this.state={
            imgWidth:150,
            imgHeight:150,
        }

    }
    render() {
        let product = this.props.product;
        return <div style={{background: "#F99B76", margin: "10px", padding: "40px", height:190, width:190}}>
            {<div>
                <img src={product.img} width={this.state.imgWidth} height={this.state.imgHeight}
                     onMouseEnter={this.handleMouseEnter}
                     onMouseLeave={this.handleMouseLeave}
                     alt="..."/>
            </div>}
            <div >
                <div>
                    <h7>
                        {product.name}
                    </h7>
                </div>
                <div>
                    <span>${product.price}</span>
                </div>
                <div>
                    <span>quantity : {product.cartQuantity}</span>
                </div>
            </div>
        </div>
    }

    handleMouseEnter = () => {
        this.setState({
            imgWidth: 180,
            imgHeight: 180
        })
    }
    handleMouseLeave = () => {
        this.setState({
            imgWidth: 150,
            imgHeight: 150
        })
    }

}
