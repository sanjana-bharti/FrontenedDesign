import React,{Component} from "react";
import {Product} from "./Product";
import bllueberry from "../img/bllueberry.jpeg"
import cheesecake from "../img/cheesecake.jpeg"
import redvelvet from "../img/redvelvet.jpeg"
import Truffles from "../img/Truffles.jpeg"
import {Cart} from "./Cart";

export class HomePage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            products: [
                {
                    id: 'p1',
                    name: 'CHEESE CAKE',
                    price: '25',
                    img: cheesecake,
                    quantity: 3,
                    cartQuantity: 0
                },
                {
                    id: 'p2',
                    name: 'RED VELVET',
                    price: '30',
                    img: redvelvet,
                    quantity: 5,
                    cartQuantity: 0
                },
                {
                    id: 'p3',
                    name: 'TRUFFLES',
                    price: '35',
                    img: Truffles,
                    quantity: 7,
                    cartQuantity: 0
                },
                {
                    id: 'p4',
                    name: 'BLUE BERRY ',
                    price: '20',
                    img: bllueberry,
                    quantity: 4,
                    cartQuantity: 0
                },
            ],
            cartItems:[]
        }
    }

    render() {
        let products=this.state.products;
        let cartItems=this.state.cartItems;
        return <div>
            <h1 style={{marginBottom: "100px",color:"#C579D2"}}> BAKERY </h1>
            <div
                style={{display: 'flex', flexDirection: 'row', justifyContent: 'space-between', background: "#FBFBFB"}}>
                {
                    products.map((product) => {
                        return <Product key={product.id} product={product} manageAddToCart={this.manageAddToCart}
                                        manageDeleteFromCart={this.manageDeleteFromCart}/>
                    })
                }
            </div>
            <div>
                <Cart cartItems={cartItems}/>
            </div>
        </div>
    }

    manageAddToCart = (currentProduct, isAlreadyPresent) => {
        if (!isAlreadyPresent) {
            this.state.cartItems.push(currentProduct)
        }
        this.setState({
            cartItems: this.state.cartItems
        })
        console.log(this.state.cartItems);
    }
    manageDeleteFromCart=(currentProduct,isLastInCart)=>{
        let newCartItems=[];
        if(isLastInCart)
        {
            this.state.cartItems.forEach((item,index)=>{
                if(item.id!==currentProduct.id)
                {
                    newCartItems.push(item);
                }
            })
            this.setState({
                cartItems:newCartItems
            })
        }
    }
}
