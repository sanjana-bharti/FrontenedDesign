import React,{Component} from "react";
import cart from "../img/cart.png"
import trash from "../img/trash.png"
export class Product extends Component
{

    constructor(props) {
        super(props);
        this.state={
            imgWidth:250,
            imgHeight:250,
            isSoldOut:false
        }

    }
    render() {
        let product = this.props.product;
        let backgroundColor=this.state.isSoldOut?"#B5ADB6":"#F5DAF6";
        return <div style={{background: backgroundColor, margin: "10px", padding: "40px"}}>
            {<div>
                <img src={product.img} width={this.state.imgWidth} height={this.state.imgHeight}
                     onMouseEnter={this.handleMouseEnter}
                     onMouseLeave={this.handleMouseLeave}
                     alt="..."/>
            </div>}
            <div >
                <div>
                    <h7>
                        {product.name}
                    </h7>
                </div>
                <div>
                    <span>${product.price}</span>
                </div>
                <div>
                    <img onClick={this.handleAddToCart} src={cart} width={20} height={20}/>
                </div>
                <div>
                    <img onClick={this.handleDeleteItem} src={trash} width={20} height={20}/>
                </div>
            </div>
        </div>
    }

    handleMouseEnter = () => {
        this.setState({
            imgWidth: 270,
            imgHeight: 270
        })
    }
    handleMouseLeave = () => {
        this.setState({
            imgWidth: 250,
            imgHeight: 250
        })
    }
    handleAddToCart=()=>{
        if (this.props.product.quantity > 0) {
            this.props.product.cartQuantity++;
            this.props.product.quantity--;
            this.props.manageAddToCart(this.props.product, this.props.product.cartQuantity > 1)
            if (this.props.product.quantity <= 0)
                this.setState({isSoldOut: true});
        }
        else
        {
            alert("This Product is sold Out")
        }
    }
    handleDeleteItem=()=>
    {
        if(this.props.product.cartQuantity<1)
        {
            alert("This item is not present in cart, no need to delete it !");
        }
        else
        {
            if(this.props.product.quantity<=0)
                this.setState({isSoldOut:false})
            this.props.product.cartQuantity--;
            this.props.product.quantity++;
            this.props.manageDeleteFromCart(this.props.product,this.props.product.cartQuantity<=0);

        }
    }
}
